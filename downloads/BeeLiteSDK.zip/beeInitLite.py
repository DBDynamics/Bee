from DBDynamics import Bee
import time

# for windows,  m = Bee('COM3', baudrate=250000)
# for linux, m = Bee('/dev/ttyUSB0', baudrate=250000)
# for USB-485-Lite(General Purpose USB 485 Converter), baudrate=250000
# for USB-485(with MCU inside, Produced by DBD), baudrate=2000000

m = Bee('/dev/ttyUSB0', 250000)
mid = 1
m.setTargetVelocity(mid, 200)
m.setAccTime(mid, 500)
m.setPositionMode(mid)
m.setTargetPosition(mid, 0)
m.setRunningCurrent(mid, 800)
m.setKeepingCurrent(mid, 300)
m.setHomingDirection(mid, 1)
m.setHomingLevel(mid, 0)
m.setPowerOn(mid)
time.sleep(1)
m.saveParameters(1)
m.stop()
