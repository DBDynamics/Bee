from DBDynamics import Bee
import time

# for windows,  m = Bee('COM3', baudrate=250000)
# for linux, m = Bee('/dev/ttyUSB0', baudrate=250000)
# for USB-485-Lite(General Purpose USB 485 Converter), baudrate=250000
# for USB-485(with MCU inside, Produced by DBD), baudrate=2000000

m = Bee('/dev/ttyUSB0', baudrate=250000)
mid = 1
m.setPowerOn(id=mid)

# Setup Homing Mode Parameters:
m.setTargetVelocity(id=mid, value=1000)
m.setHomingDirection(id=mid, value=-1)
m.setHomingLevel(id=mid, value=1)

# Enter Homing Mode, Start Homing
m.setHomingMode(id=mid)

m.stop()
