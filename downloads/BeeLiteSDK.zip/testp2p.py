from DBDynamics import Bee
import time

m = Bee('/dev/ttyUSB0', baudrate=250000)
mid = 2
# m.setTargetPosition(mid, 51200 * -10)
m.setPowerOn(mid)
m.setAccTime(mid, 2000)
m.setTargetVelocity(mid, 1000)

for i in range(0, 1):
    m.setTargetPosition(mid, 51200 * 10)
    # m.setOutputIO(mid, 5000)
    # time.sleep(5)
    m.waitTargetPositionReached(mid)
    m.setTargetPosition(mid, 51200 * 0)
    # m.setOutputIO(mid, 50)
    # time.sleep(5)
    m.waitTargetPositionReached(mid)
m.stop()
