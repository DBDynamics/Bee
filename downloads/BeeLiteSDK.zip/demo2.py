from DBDynamics import Bee
import time

# in this demo, we have 2 devices online: [1, 2]
m = Bee('/dev/ttyUSB0', baudrate=250000)

# set Power On
m.setPowerOn(id=1)
m.setPowerOn(id=1)

# set acc & velocity
m.setAccTime(id=1, value=500)
m.setAccTime(id=2, value=500)
m.setTargetVelocity(id=1, value=1000)
m.setTargetVelocity(id=2, value=1000)

# action together
for i in range(0, 1):
    m.setTargetPosition(id=1, value=51200 * 5)
    m.setTargetPosition(id=2, value=51200 * 5)
    m.waitTargetPositionReached(id=1)
    m.waitTargetPositionReached(id=2)

    m.setTargetPosition(id=1, value=51200 * 0)
    m.setTargetPosition(id=2, value=51200 * 0)
    m.waitTargetPositionReached(id=1)
    m.waitTargetPositionReached(id=2)

# action one after one
for i in range(0, 1):
    m.setTargetPosition(id=1, value=51200 * 5)
    m.waitTargetPositionReached(id=1)
    m.setTargetPosition(id=2, value=51200 * 5)
    m.waitTargetPositionReached(id=2)

    m.setTargetPosition(id=1, value=51200 * 0)
    m.waitTargetPositionReached(id=1)
    m.setTargetPosition(id=2, value=51200 * 0)
    m.waitTargetPositionReached(id=2)

m.stop()
