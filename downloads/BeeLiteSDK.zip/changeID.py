from DBDynamics import Bee
import time

# for windows,  m = Bee('COM3', baudrate=250000)
# for linux, m = Bee('/dev/ttyUSB0', baudrate=250000)
# for USB-485-Lite(General Purpose USB 485 Converter), baudrate=250000
# for USB-485(with MCU inside, Produced by DBD), baudrate=2000000

m = Bee('/dev/ttyUSB0', baudrate=250000)

currentID = 1
targetID = 2
m.changeID(currentID, targetID)

a = m.scanDevices()
print(a)
time.sleep(1)

m.stop()
