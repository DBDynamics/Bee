from DBDynamics import Bee
import time

# for windows,  m = Bee('COM3', baudrate=250000)
# for linux, m = Bee('/dev/ttyUSB0', baudrate=250000)
# for USB-485-Lite(General Purpose USB 485 Converter), baudrate=250000
# for USB-485(with MCU inside, Produced by DBD), baudrate=2000000


# Scan Devices, and print the list.
m = Bee('/dev/ttyUSB0', baudrate=250000)
a = m.scanDevices()
print(a)
m.stop()
