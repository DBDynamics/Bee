#include "program.h"

void programNew( programType *program)
{
    program->currentLine=0;
    program->totalLine=1;
}


void programSave(const char * filename, programType *program)
{
    FILE * pFile;
    pFile = fopen (filename , "wb+");
    if (pFile == NULL) perror ("Error opening file");
    else
    {
        int n = fwrite ((char*)program,1,sizeof(programType),pFile);
        fclose (pFile);
    }
}

int programOpen(const char * filename, programType *program)
{
    FILE * pFile;
    pFile = fopen (filename , "rb");
    if (pFile == NULL)
    {
        perror ("Error opening file");
        return 0;
    }
    else
    {
        fread ((char*)program,1,sizeof(programType),pFile);
        fclose (pFile);
        return 1;
    }
}


int programCheckCmd(QString cmd)
{
    if(cmd == "SETMODE")
    {
        return 1;
    }
    if(cmd == "SETEN")
    {
        return 2;
    }
    if(cmd == "SETIO")
    {
        return 3;
    }
    if(cmd == "MOVABS")
    {
        return 10;
    }
    if(cmd == "MOVZERO")
    {
        return 11;
    }
    if(cmd == "DELAY")
    {
        return 20;
    }
    return 0;
}

QString programParseCmd(int cmd)
{
    if(cmd == 1)
    {
        return "SETMODE";
    }
    if(cmd == 2)
    {
        return "SETEN";
    }
    if(cmd == 3)
    {
        return "SETIO";
    }
    if(cmd == 10)
    {
        return "MOVABS";
    }
    if(cmd == 11)
    {
        return "MOVZERO";
    }
    if(cmd == 20)
    {
        return "DELAY";
    }

}

void programRun(int cmd, int id, int value)
{
    switch(cmd)
    {
    case 1:// SETMODE
        sendCAN(FUNC_TSDO+id,ModesofOperationIndex,WriteSubIndex,value);
        break;
    case 2:// SETEN
        sendCAN(FUNC_TSDO+id,ControlWordIndex,WriteSubIndex,value);
        break;
    case 3://SETIO
        sendCAN(FUNC_TSDO+id,IO_OUT_Index,WriteSubIndex,value);
        break;
    case 10://MOVABS
        sendCAN(FUNC_TSDO+id,StepperRunPosIndex,WriteSubIndex,value);
        break;
    case 11://MOVZERO
        sendCAN(FUNC_TSDO+id,ModesofOperationIndex,WriteSubIndex,OPMODE_HOMING);
        break;
    case 20://Delay
        //sendCAN(FUNC_FREE,0,0,0);
        break;
    default:
        break;
    }
}
