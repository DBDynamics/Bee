#include "tuner.h"
#include "ui_tuner.h"

Tuner::Tuner(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Tuner)
{
    ui->setupUi(this);

    /* Motor Variable Initialize */
    motor.resize(32);
    for(int i=0;i<32;i++)
    {
        motor[i].resize(8);
        for(int j=0;j<8;j++)
        {
            motor[i][j].resize(32);
        }
    }
    /* Init Variables */
    for(int i=0;i<32;i++)
    {
        for(int j=0;j<8;j++)
        {
            for(int k=0;k<32;k++)
            {
                motor[i][j][k]=0;
            }
        }
    }
    readParaFlag = 0;
    timer1_counter = 0;
    rxReadyFlag = 0;
    connectionFlag = 0;
    connectionFlag_LastStatus = -1;
    StatusWord_Last = -1;
    ControlWord_Last = -1;
    currentSubID = 0;
    currentID = 0;

    /* Check avaliable communication ports */
    foreach (const QSerialPortInfo &qspinfo, QSerialPortInfo::availablePorts())
    {
       ui->comboBox_serialport->addItem(qspinfo.portName());
    }

    ui->pushButton_servoon->setStyleSheet("background-color:green;");


    /* serial Port */
    serial = new QSerialPort(this);

    /* Timer1 runs at 1ms for sending and reveiving messages */
    timer1 = new QTimer(this);
    connect(timer1,SIGNAL(timeout()),this,SLOT(Timer1()));
    timer1->start(5);

    /* Timer2 runs at 50ms for updating UI */
    timer2 = new QTimer(this);
    connect(timer2,SIGNAL(timeout()),this,SLOT(Timer2()));
    timer2->start(50);

    /* Timer3 runs for scanning Devices */
    timer3 = new QTimer(this);
    connect(timer3,SIGNAL(timeout()),this,SLOT(Timer3()));

    /* Timer4 runs for reading parameters */
    timer4 = new QTimer(this);
    connect(timer4,SIGNAL(timeout()),this,SLOT(Timer4()));

    /* Interface Lock */
    ui->groupBox_device->setDisabled(true);
    ui->groupBox_parameter->setDisabled(true);
    ui->groupBox_operation->setDisabled(true);
    ui->lineEdit_id->setDisabled(true);
    ui->pushButton_changeID_Confirm->setDisabled(true);
}

Tuner::~Tuner()
{
    delete ui;
}

void Tuner::on_pushButton_serialPort_clicked()
{
    sendCmdMsgQueue.clear();
    if(ui->pushButton_serialPort->text()=="打开")
    {
        QString portName = ui->comboBox_serialport->currentText();
        serial->setPortName(portName);
        serial->open(QIODevice::ReadWrite);
        if(serial->isOpen())
        {
            serial->setBaudRate(2000000);
            serial->setDataBits(QSerialPort::Data8);
            serial->setParity(QSerialPort::NoParity);
            serial->setStopBits(QSerialPort::OneStop);
            serial->setFlowControl(QSerialPort::NoFlowControl);
            serial->setReadBufferSize(32);

            ui->pushButton_serialPort->setText("关闭");
            ui->pushButton_serialPortScan->setDisabled(true);
            ui->comboBox_serialport->setDisabled(true);
        }
        else
        {
            ui->pushButton_serialPort->setText("打开");
            ui->pushButton_serialPortScan->setDisabled(false);
            ui->comboBox_serialport->setDisabled(false);
        }
    }
    else
    {
        serial->close();
        ui->pushButton_serialPort->setText("打开");
        ui->pushButton_serialPortScan->setDisabled(false);
        ui->comboBox_serialport->setDisabled(false);
    }
}


void Tuner::receiveData()
{
    long long n = serial->bytesAvailable();

    if(n>=8)
    {
//        qDebug()<<n;
        QByteArray rx = serial->readAll();
        serial->clear();
        if(rx.length()==8)
        {
            rxReadyFlag = 1;
            sdoMsgObj msg;
            memcpy(&msg,rx.data(),8);
            updateRxMsg(msg);
        }
    }
}

void Tuner::on_pushButton_servoon_clicked()
{
    if(ui->pushButton_servoon->text()=="启动")
    {
        sendSDO(FuncWriteSDO, currentID, currentSubID, ControlWordIndex, 1);
        ui->pushButton_servoon->setText("停止");
        ui->pushButton_servoon->setStyleSheet("background-color:red;");

    }
    else
    {
        sendSDO(FuncWriteSDO, currentID, currentSubID, ControlWordIndex, 0);
        ui->pushButton_servoon->setText("启动");
        ui->pushButton_servoon->setStyleSheet("background-color:green;");
        ui->pushButton_save->setDisabled(false);
    }
}

/* Timer1 for Serial Port Communication */
void Tuner::Timer1()
{
    if(serial->isOpen())
    {
        receiveData();
        if(rxReadyFlag == 1)
        {
            sendData();
            timer1_counter = 0;
            rxReadyFlag = 0;
            connectionFlag = 1;
        }
        else // Every 20ms retry to send msg
        {
            timer1_counter++;
            if(timer1_counter==50)
            {
                timer1_counter = 0;
                sendData();
                rxReadyFlag = 0;
            }
        }
    }
    else
    {
        connectionFlag=0;
    }
}

void Tuner::Timer2()
{
    /* Update when Status Changes */
    if(connectionFlag_LastStatus != connectionFlag)
    {
        if(connectionFlag==1)
        {
            ui->label_connection->setStyleSheet("background-color:green;");
            ui->groupBox_device->setEnabled(true);
            ui->groupBox_operation->setEnabled(true);
            ui->groupBox_parameter->setEnabled(true);
        }
        else
        {
            ui->label_connection->setStyleSheet("background-color:red;");
            ui->groupBox_device->setEnabled(false);
            ui->groupBox_operation->setEnabled(false);
            ui->groupBox_parameter->setEnabled(false);
        }
        connectionFlag_LastStatus = connectionFlag;
    }
    /* Periodic Task */
    if(connectionFlag==1)
    {
        sendSDO(FuncReadSDO, currentID, currentSubID, ActualPositionIndex, 0);
        sendSDO(FuncReadSDO, currentID, currentSubID, TargetPositionIndex, 0);
        sendSDO(FuncReadSDO, currentID, currentSubID, StatusWordIndex, 0);
        ui->label_stepper_runpos->setText(QString::number(motor[currentID][currentSubID][ActualPositionIndex]));
        ui->label_stepper_currentpos->setText(QString::number(motor[currentID][currentSubID][TargetPositionIndex]));

        /* to reduce cpu */
        if(StatusWord_Last != motor[currentID][currentSubID][StatusWordIndex])
        {
            StatusWord_Last = motor[currentID][currentSubID][StatusWordIndex];
            /* if Device Enable Status changed */
            if( ControlWord_Last !=  (motor[currentID][currentSubID][StatusWordIndex]&STATUS_DEVICE_ENABLED))
            {
                ControlWord_Last = (motor[currentID][currentSubID][StatusWordIndex]&STATUS_DEVICE_ENABLED);
                if((motor[currentID][currentSubID][StatusWordIndex]&STATUS_DEVICE_ENABLED) == STATUS_DEVICE_ENABLED)
                {
                    ui->label_enable->setStyleSheet("background-color:green;");
                    ui->pushButton_servoon->setText("停止");
                    ui->pushButton_servoon->setStyleSheet("background-color:red;");
//                    ui->pushButton_save->setDisabled(true);
//                    ui->pushButton_update->setDisabled(true);
                }
                else
                {
                    ui->label_enable->setStyleSheet("background-color:red;");
                    ui->pushButton_servoon->setText("启动");
                    ui->pushButton_servoon->setStyleSheet("background-color:green;");
                    ui->pushButton_save->setDisabled(false);
                    ui->pushButton_update->setDisabled(false);
                }
            }

            if((motor[currentID][currentSubID][StatusWordIndex]&STATUS_TARGET_REACHED) != STATUS_TARGET_REACHED)
            {
                ui->label_running->setStyleSheet("background-color:red;");
            }
            else
            {
                ui->label_running->setStyleSheet("background-color:green;");
            }

            if((motor[currentID][currentSubID][StatusWordIndex]&STATUS_IO_INPUT) == STATUS_IO_INPUT)
            {
                 ui->label_sensor->setStyleSheet("background-color:green;");
            }
            else
            {
                ui->label_sensor->setStyleSheet("background-color:red;");
            }
        }
    }
}


/*
 * Low Level Communication Function
 * Send a CAN Frame over Serial Port
 * This function will be called in a fast timer interrupt*/
void Tuner::sendSDOMsg(sdoMsgObj msg)
{
    serial->write((char*)(&msg),8);
}
/*
 * This Function will be called in a 0.9ms timer update event
 * to make sure the stableness of the tx data stream, the timer is less than 0.9ms,which is faster than the consumer*/
void Tuner::sendData(void)
{
    sdoMsgObj msg;
    /* Command Queue has higher priority */
    if(!sendCmdMsgQueue.isEmpty())
    {
        sendSDOMsg(sendCmdMsgQueue.front());
        sendCmdMsgQueue.pop_front();
    }
    else
    {
        msg.Func = FuncFree;
        msg.ID = 0;
        msg.SubID = 0;
        msg.Index = 0;
        msg.Data = 0;
        sendSDOMsg(msg);
    }
}

void Tuner::on_pushButton_update_clicked()
{
    if(ui->checkBox_multi_modify->isChecked())
    {
        int startid = ui->lineEdit_id_start->text().toInt();
        int endid = ui->lineEdit_id_end->text().toInt();
        int counter = 0;
        for(int i=startid;i<=endid;i++)
        {
            for(int j=0;j<8;j++)
            {
                sendSDO(FuncWriteSDO, i, j, StepperCurrentRunIndex, ui->lineEdit_run_current->text().toInt());
                sendSDO(FuncWriteSDO, i, j, StepperCurrentBoostIndex, 0);
                sendSDO(FuncWriteSDO, i, j, StepperBoostTimeIndex, 500);
                sendSDO(FuncWriteSDO, i, j, StepperCurrentKeepIndex, ui->lineEdit_hold_current->text().toInt());
                sendSDO(FuncWriteSDO, i, j, StepperRuntoKeepTimeIndex, 500);
                if(ui->comboBox_dir->currentIndex()==0)
                {
                    sendSDO(FuncWriteSDO, i, j, HomingDirIndex, 1);
                }
                else
                {
                    sendSDO(FuncWriteSDO, i, j, HomingDirIndex, -1);
                }
                if(ui->comboBox_level->currentIndex() == 0)
                {
                    sendSDO(FuncWriteSDO, i, j, HomingLevelIndex, 1);
                }
                else
                {
                    sendSDO(FuncWriteSDO, i, j, HomingLevelIndex, 0);
                }

                sendSDO(FuncWriteSDO, i, j, ProfileAccTimeIndex, ui->lineEdit_acc_time->text().toInt());
                sendSDO(FuncWriteSDO, i, j, TargetVelocityIndex, ui->lineEdit_vel->text().toInt());

                switch(ui->comboBox_opmode->currentIndex())
                {
                case 0:
                    motor[i][j][OperationModeIndex] = OPMODE_PROFILE_POSITION;
                    break;
                case 1:
                    motor[i][j][OperationModeIndex] = OPMODE_PROFILE_VELOCITY;
                    break;
                case 2:
                    motor[i][j][OperationModeIndex] = OPMODE_PROFILE_POSITION_SYNC;
                    break;
                case 3:
                    motor[i][j][OperationModeIndex] = OPMODE_PROFILE_VELOCITY_SYNC;
                    break;
                case 4:
                    motor[i][j][OperationModeIndex] = OPMODE_POSITION_ENCODER;
                    break;
                case 5:
                    motor[i][j][OperationModeIndex] = OPMODE_INTERPOLATION_POSITION_SYNC;
                    break;
                case 6:
                    motor[i][j][OperationModeIndex] = OPMODE_SENSOR_FLIP;
                    break;
                default:break;
                }
                sendSDO(FuncWriteSDO, i, j, OperationModeIndex, motor[i][j][OperationModeIndex]);
                counter++;
            }
        }
        ui->statusBar->showMessage("共更新"+QString::number(counter)+"台电机参数",1500);
    }
    else
    {
        sendSDO(FuncWriteSDO, currentID, currentSubID, StepperCurrentRunIndex, ui->lineEdit_run_current->text().toInt());
        sendSDO(FuncWriteSDO, currentID, currentSubID, StepperCurrentBoostIndex, 0);
        sendSDO(FuncWriteSDO, currentID, currentSubID, StepperBoostTimeIndex, 0);
        sendSDO(FuncWriteSDO, currentID, currentSubID, StepperCurrentKeepIndex, ui->lineEdit_hold_current->text().toInt());
        sendSDO(FuncWriteSDO, currentID, currentSubID, StepperRuntoKeepTimeIndex, 500);
        if(ui->comboBox_dir->currentIndex()==0)
        {
            sendSDO(FuncWriteSDO, currentID, currentSubID, HomingDirIndex, 1);
        }
        else
        {
            sendSDO(FuncWriteSDO, currentID, currentSubID, HomingDirIndex, -1);
        }
        if(ui->comboBox_level->currentIndex() == 0)
        {
            sendSDO(FuncWriteSDO, currentID, currentSubID, HomingLevelIndex, 1);
        }
        else
        {
            sendSDO(FuncWriteSDO, currentID, currentSubID, HomingLevelIndex, 0);
        }

        sendSDO(FuncWriteSDO, currentID, currentSubID, ProfileAccTimeIndex, ui->lineEdit_acc_time->text().toInt());
        sendSDO(FuncWriteSDO, currentID, currentSubID, TargetVelocityIndex, ui->lineEdit_vel->text().toInt());

        switch(ui->comboBox_opmode->currentIndex())
        {
        case 0:
            motor[currentID][currentSubID][OperationModeIndex] = OPMODE_PROFILE_POSITION;
            break;
        case 1:
            motor[currentID][currentSubID][OperationModeIndex] = OPMODE_PROFILE_VELOCITY;
            break;
        case 2:
            motor[currentID][currentSubID][OperationModeIndex] = OPMODE_PROFILE_POSITION_SYNC;
            break;
        case 3:
            motor[currentID][currentSubID][OperationModeIndex] = OPMODE_PROFILE_VELOCITY_SYNC;
            break;
        case 4:
            motor[currentID][currentSubID][OperationModeIndex] = OPMODE_POSITION_ENCODER;
            break;
        case 5:
            motor[currentID][currentSubID][OperationModeIndex] = OPMODE_INTERPOLATION_POSITION_SYNC;
            break;
        case 6:
            motor[currentID][currentSubID][OperationModeIndex] = OPMODE_SENSOR_FLIP;
            break;
        default:break;
        }
        sendSDO(FuncWriteSDO, currentID, currentSubID, OperationModeIndex, motor[currentID][currentSubID][OperationModeIndex]);
        ui->statusBar->showMessage("电机("+QString::number(currentID)+","+QString::number(currentSubID)+")参数已更新",1500);

        switch(ui->comboBox_baudrate->currentIndex())
        {
        case 0:
            motor[currentID][0][BaudrateIndex] = BAUDRATE_10M;
            break;
        case 1:
            motor[currentID][0][BaudrateIndex] = BAUDRATE_5M;
            break;
        case 2:
            motor[currentID][0][BaudrateIndex] = BAUDRATE_2M;
            break;
        case 3:
            motor[currentID][0][BaudrateIndex] = BAUDRATE_1M;
            break;
        case 4:
            motor[currentID][0][BaudrateIndex] = BAUDRATE_250K;
            break;
        default:break;
        }
        sendSDO(FuncWriteSDO, currentID, 0, BaudrateIndex, motor[currentID][0][BaudrateIndex]);
    }
}

void Tuner::on_pushButton_save_clicked()
{
    if(ui->checkBox_multi_modify->isChecked())
    {
        int startid = ui->lineEdit_id_start->text().toInt();
        int endid = ui->lineEdit_id_end->text().toInt();
        for(int i=startid;i<=endid;i++)
        {
            sendSDO(FuncOperationSDO,i,currentSubID,MemoryIndex,0);
        }
    }
    else
    {
        sendSDO(FuncOperationSDO,currentID,currentSubID,MemoryIndex,0);
    }

}

void Tuner::on_pushButton_read_clicked()
{
    sendSDO(FuncReadSDO, currentID, currentSubID, StepperCurrentRunIndex, 0);
    sendSDO(FuncReadSDO, currentID, currentSubID, StepperCurrentBoostIndex, 0);
    sendSDO(FuncReadSDO, currentID, currentSubID, StepperCurrentKeepIndex, 0);
    sendSDO(FuncReadSDO, currentID, currentSubID, HomingDirIndex, 0);
    sendSDO(FuncReadSDO, currentID, currentSubID, HomingLevelIndex, 0);
    sendSDO(FuncReadSDO, currentID, currentSubID, ProfileAccTimeIndex, 0);
    sendSDO(FuncReadSDO, currentID, currentSubID, TargetVelocityIndex, 0);
    sendSDO(FuncReadSDO, currentID, currentSubID, OperationModeIndex, 0);
    sendSDO(FuncReadSDO, currentID, currentSubID, BaudrateIndex, 0);
    timer4->start(200);
}


void Tuner::on_lineEdit_id_returnPressed()
{
    int id = ui->lineEdit_id->text().toInt();
    for(int i=0;i<8; i++)
    {
        sendSDO(FuncWriteSDO, currentID, i, DeviceIDIndex, id);
    }
    ui->pushButton_scan->click();
}


void Tuner::on_lineEdit_run_pos_returnPressed()
{
    if(ui->comboBox_runcmd->currentIndex()==0)// Absolute Pos
    {
        motor[currentID][currentSubID][TargetPositionIndex] = ui->lineEdit_run_pos->text().toInt();
        sendSDO(FuncWriteSDO, currentID, currentSubID, TargetPositionIndex, motor[currentID][currentSubID][TargetPositionIndex]);
    }
    else if(ui->comboBox_runcmd->currentIndex()==1)// Increament Pos
    {
        motor[currentID][currentSubID][TargetPositionIndex] += ui->lineEdit_run_pos->text().toInt();
        sendSDO(FuncWriteSDO, currentID, currentSubID, TargetPositionIndex, motor[currentID][currentSubID][TargetPositionIndex]);
    }
    else if(ui->comboBox_runcmd->currentIndex()==2)
    {
        motor[currentID][currentSubID][TargetVelocityIndex] = ui->lineEdit_run_pos->text().toInt();
        sendSDO(FuncWriteSDO, currentID, currentSubID, TargetVelocityIndex, motor[currentID][currentSubID][TargetVelocityIndex]);
    }
    ui->label_stepper_runpos->setText(QString::number(motor[currentID][currentSubID][TargetPositionIndex]));
}

void Tuner::on_pushButton_home_clicked()
{
    motor[currentID][currentSubID][TargetPositionIndex]=0;
    sendSDO(FuncWriteSDO, currentID, currentSubID, OperationModeIndex, OPMODE_HOMING);
}


void Tuner::on_checkBox_multi_modify_clicked()
{
    if(ui->checkBox_multi_modify->isChecked())
    {
        ui->pushButton_read->setDisabled(true);
        ui->lineEdit_id_start->setDisabled(false);
        ui->lineEdit_id_end->setDisabled(false);
        ui->groupBox_device->setDisabled(true);
        ui->lineEdit_id_start->setText(ui->comboBox_id->itemText(0));
        ui->lineEdit_id_end->setText(ui->comboBox_id->itemText(ui->comboBox_id->count()-1));
    }
    else
    {
        ui->pushButton_read->setDisabled(false);
        ui->lineEdit_id_start->setDisabled(true);
        ui->lineEdit_id_end->setDisabled(true);
        ui->groupBox_device->setEnabled(true);
    }
}


void Tuner::on_pushButton_run_clicked()
{
    ui->lineEdit_run_pos->returnPressed();
}

void Tuner::on_comboBox_id_currentTextChanged(const QString &arg1)
{
    currentID=ui->comboBox_id->currentText().toInt();
}

void Tuner::updateRxMsg(sdoMsgObj msg)
{
    if(msg.Func == FuncReadSDO_OK)
    {
        motor[msg.ID][msg.SubID][msg.Index] = msg.Data;
    }
}

/*
 * Append a CAN Message into the TX buffer */
void Tuner::sendSDO(int Func, int ID,int SubID, int Index, int Data)
{
    sdoMsgObj msg;
    msg.Func = (unsigned char)Func;
    msg.ID = (unsigned char)ID;
    msg.SubID = (unsigned char)SubID;
    msg.Index = (unsigned char)Index;
    msg.Data = Data;
    sendCmdMsgQueue.append(msg);
}

void Tuner::on_pushButton_scan_clicked()
{
    for(int i=0;i<32;i++)
    {
        motor[i][0][DeviceIDIndex] = -1;
        sendSDO(FuncReadSDO,i,0,DeviceIDIndex,0);
    }
    timer3->start(1200);
    ui->comboBox_id->clear();
    ui->statusBar->showMessage("Searching Online Devices...",3000);
}

void Tuner::Timer3()
{
    timer3->stop();
    int num=0;
    for(int i=0;i<32;i++)
    {
        if(motor[i][0][DeviceIDIndex]==i)
        {
            ui->comboBox_id->addItem(QString::number(i));
            num++;
        }
    }
    ui->statusBar->showMessage("Found "+QString::number(num)+" Devices!",1000);
}

void Tuner::on_comboBox_subid_currentTextChanged(const QString &arg1)
{
    currentSubID=ui->comboBox_subid->currentText().toInt();
}

void Tuner::Timer4()
{
    timer4->stop();
    ui->lineEdit_run_current->setText(QString::number(motor[currentID][currentSubID][StepperCurrentRunIndex]));
    ui->lineEdit_hold_current->setText(QString::number(motor[currentID][currentSubID][StepperCurrentKeepIndex]));
    if(motor[currentID][currentSubID][HomingDirIndex]==1)
    {
        ui->comboBox_dir->setCurrentIndex(0);
    }
    else
    {
        ui->comboBox_dir->setCurrentIndex(1);
    }
    if(motor[currentID][currentSubID][HomingLevelIndex]==1)
    {
        ui->comboBox_level->setCurrentIndex(0);
    }
    else
    {
        ui->comboBox_level->setCurrentIndex(1);
    }
    ui->lineEdit_acc_time->setText(QString::number(motor[currentID][currentSubID][ProfileAccTimeIndex]));
    ui->lineEdit_vel->setText(QString::number(motor[currentID][currentSubID][TargetVelocityIndex]));
    switch(motor[currentID][currentSubID][OperationModeIndex])
    {
    case OPMODE_PROFILE_POSITION:
        ui->comboBox_opmode->setCurrentIndex(0);
        break;
    case OPMODE_PROFILE_VELOCITY:
        ui->comboBox_opmode->setCurrentIndex(1);
        break;
    case OPMODE_INTERPOLATION_POSITION_SYNC:
        ui->comboBox_opmode->setCurrentIndex(5);
        break;
    case OPMODE_SENSOR_FLIP:
        ui->comboBox_opmode->setCurrentIndex(6);
        break;
    default:
        break;
    }
    switch(motor[currentID][0][BaudrateIndex])
    {
    case BAUDRATE_10M:
        ui->comboBox_baudrate->setCurrentIndex(0);
        break;
    case BAUDRATE_5M:
        ui->comboBox_baudrate->setCurrentIndex(1);
        break;
    case BAUDRATE_2M:
        ui->comboBox_baudrate->setCurrentIndex(2);
        break;
    case BAUDRATE_1M:
        ui->comboBox_baudrate->setCurrentIndex(3);
        break;
    case BAUDRATE_250K:
        ui->comboBox_baudrate->setCurrentIndex(4);
        break;

    default:
        break;
    }

    ui->statusBar->showMessage("参数已读取",1500);
}


void Tuner::on_comboBox_id_currentIndexChanged(int index)
{
    /* If exits device , then read parameters */
    if(ui->comboBox_id->count()!=0)
    {
        ui->pushButton_read->click();
    }
}

void Tuner::on_comboBox_subid_currentIndexChanged(int index)
{
    ui->pushButton_read->click();
}

void Tuner::on_pushButton_serialPortScan_clicked()
{
    ui->comboBox_serialport->clear();
    /* Check avaliable communication ports */
    foreach (const QSerialPortInfo &qspinfo, QSerialPortInfo::availablePorts())
    {
       ui->comboBox_serialport->addItem(qspinfo.portName());
    }
}

void Tuner::on_pushButton_changeID_Confirm_clicked()
{
    ui->lineEdit_id->returnPressed();
}

void Tuner::on_checkBox_multi_modify_2_stateChanged(int arg1)
{
    if(arg1 == 0)
    {
        ui->lineEdit_id->setDisabled(true);
        ui->pushButton_changeID_Confirm->setDisabled(true);
        ui->groupBox_operation->setDisabled(false);
    }
    else
    {
        ui->lineEdit_id->setEnabled(true);
        ui->pushButton_changeID_Confirm->setEnabled(true);
        ui->groupBox_operation->setEnabled(false);
    }
}
