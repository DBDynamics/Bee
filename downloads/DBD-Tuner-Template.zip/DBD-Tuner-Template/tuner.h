#ifndef TUNER_H
#define TUNER_H

#include <QMainWindow>
#include <QSerialPort>
#include <QTimer>
#include "link.h"
#include <QSerialPortInfo>
#include <stdio.h>
#include <stdlib.h>
#include <queue>
#include <QDebug>
#include <QtNetwork>
#include <QFileDialog>
#include <QString>
#include <QVector>
#include <QScreen>

namespace Ui {
class Tuner;
}

class Tuner : public QMainWindow
{
    Q_OBJECT

public:
    explicit Tuner(QWidget *parent = 0);
    ~Tuner();

private slots:
    void Timer1();

    void Timer2();

    void Timer3();

    void Timer4();

    void on_pushButton_serialPort_clicked();

    void receiveData();

    void on_pushButton_servoon_clicked();

    void sendSDOMsg(sdoMsgObj msg);

    void sendData(void);

    void on_pushButton_update_clicked();

    void on_pushButton_save_clicked();

    void on_pushButton_read_clicked();

    void on_lineEdit_id_returnPressed();

    void on_lineEdit_run_pos_returnPressed();

    void on_pushButton_home_clicked();

    void on_checkBox_multi_modify_clicked();

    void on_pushButton_run_clicked();

    void on_comboBox_id_currentTextChanged(const QString &arg1);

    void updateRxMsg(sdoMsgObj msg);

    void sendSDO(int Func, int ID,int SubID, int Index, int Data);

    void on_pushButton_scan_clicked();

    void on_comboBox_subid_currentTextChanged(const QString &arg1);

    void on_comboBox_id_currentIndexChanged(int index);

    void on_comboBox_subid_currentIndexChanged(int index);

    void on_pushButton_serialPortScan_clicked();

    void on_pushButton_changeID_Confirm_clicked();

    void on_checkBox_multi_modify_2_stateChanged(int arg1);

private:
    Ui::Tuner *ui;
    QSerialPort *serial;
    /* Timer1 for sending and receiving messages */
    QTimer *timer1;
    /* Timer2 for updating the UI */
    QTimer *timer2;
    /* Timer3 for scanning Devices */
    QTimer *timer3;
    /* Timer4 for reading Parameters */
    QTimer *timer4;

    /* Connection Status Flag */
    int connectionFlag;
    int connectionFlag_LastStatus;

    /* Last Status Word */
    int StatusWord_Last;
    int ControlWord_Last;

    /* For sending timeout */
    int timer1_counter;

    /* For imcoming data ready flag */
    int rxReadyFlag;

    int readParaFlag;
//    int networkStatus;
    int currentID;
    int currentSubID;

    QVector<QVector<QVector<int>>> motor;
    QQueue<sdoMsgObj>sendCmdMsgQueue;
};

#endif // MYMOTOR_H
