#ifndef LINK_H
#define LINK_H

/* Profile for Stepper Index */
#define BoardTypeIndex 0
#define DeviceIDIndex 1
#define ControlWordIndex 2
#define OperationModeIndex 3
#define StatusWordIndex 4
#define TargetCurrentIndex 5
#define ActualCurrentIndex 6
#define TargetVelocityIndex 7
#define ActualVelocityIndex 8
#define TargetPositionIndex 9
#define ActualPositionIndex 10
#define ProfileAccTimeIndex 11
#define InterpolationTargetPostionIndex 12
#define HomingModeIndex 13
#define HomingDirIndex 14
#define HomingLevelIndex 15
#define HomingOffsetIndex 16
#define StepperCurrentRunIndex 17
#define StepperCurrentKeepIndex 18
#define StepperCurrentBoostIndex 19
#define StepperRuntoKeepTimeIndex 20
#define StepperBoostTimeIndex 21
#define IoInIndex 22
#define IoOutIndex 23
#define EncoderOffsetIndex 24
#define EncoderPolarityIndex 25
#define EncoderValueIndex 26
#define BaudrateIndex 27

/* Operation Index */
#define	MemoryIndex	1

/* SubIndex Operation Value */
#define FuncReadSDO 0
#define FuncWriteSDO 1
#define FuncReadSDO_OK 2
#define FuncWriteSDO_OK 3
#define FuncOperationSDO 4
#define FuncOperationSDO_OK 5
#define FuncFree 255

/* Operation Modes */
#define OPMODE_PWM (0)
#define OPMODE_SVPWM (1)

#define OPMODE_TORQUE (10)
#define OPMODE_SYNC_TORQUE (11)

#define OPMODE_VELOCITY (20)
#define OPMODE_PROFILE_VELOCITY (21)
#define OPMODE_INTERPOLATION_VELOCITY (22)
#define OPMODE_PROFILE_VELOCITY_SYNC (23)
#define OPMODE_INTERPOLATION_VELOCITY_SYNC (24)

#define OPMODE_POSITION (30)
#define OPMODE_PROFILE_POSITION	(31)
#define OPMODE_INTERPOLATION_POSITION (32)
#define OPMODE_PROFILE_POSITION_SYNC (33)
#define OPMODE_INTERPOLATION_POSITION_SYNC (34)
#define OPMODE_POSITION_ENCODER (35)
#define OPMODE_SENSOR_FLIP (36)
#define OPMODE_HOMING (40)

/* STATUS WORD */
#define STATUS_DEVICE_ENABLED (0X01)
#define STATUS_HOME_FIND (0X02)
#define STATUS_TARGET_REACHED (0X04)
#define STATUS_IO_INPUT (0X08)
#define STATUS_IO_INPUT2 (0X10)

#define BAUDRATE_10M 0
#define BAUDRATE_5M 1
#define BAUDRATE_2M 2
#define BAUDRATE_1M 3
#define BAUDRATE_250K 5

/* SDO Message Protocol */
typedef struct
{
    unsigned char Func;
    unsigned char Index;
    unsigned char ID;
    unsigned char SubID;
    int Data;
}sdoMsgObj;

#endif // LINK_H
