#ifndef PROGRAM_H
#define PROGRAM_H
#include "stdio.h"
#include <string.h>
#include <iostream>
#include <fstream>
#include <QString>
#include <QDebug>
#include "link.h"

typedef struct
{
    int Cmd;
    int ID;
    int Value;
    char Note[100];
}programLineType;

typedef struct
{
    int totalLine;
    int currentLine;
    programLineType line[1000];
}programType;


void programSave(const char * filename, programType *program);
void programNew( programType *program);
int programCheckCmd(QString cmd);
int programOpen(const char * filename, programType *program);
QString programParseCmd(int cmd);
void programRun(int cmd, int id, int value);
#endif // PROGRAM_H
