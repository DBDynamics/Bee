#include "tuner.h"
#include <QApplication>
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Tuner w;

    /* GUI Title */
    w.setWindowTitle("DBD Stepper Template V5.1.3");
    w.show();

    return a.exec();
}
