#!/usr/bin/python3
import time

from DBDynamics import Ant, Bee


def mainAnt():
    # Note: for Linux System Users, you can use "ls /dev/ttyU*" to find your port name
    # Note: for Windows System Users, portName='COM?', change ? to your COM number
    portName = '/dev/ttyUSB0'
    DBD = Ant(portName)

    # Your Code Start Here:
    DBD.setTargetPosition(8, -50000)
    DBD.waitTargetPositionReached(8)

    DBD.setTargetPosition(8, 50000)
    DBD.waitTargetPositionReached(8)

    # Close Communication
    DBD.stop()


def mainBee():
    portName = '/dev/ttyUSB0'  # Note: for Linux System, you can use "ls /dev/ttyU*" to find your port name
    DBD = Bee(portName)

    DBD.setHomingMode(7)
    # Your Code Start Here:
    # DBD.setTargetPosition(8, -50000)
    # DBD.waitTargetPositionReached(8)
    #
    # DBD.setTargetPosition(8, 50000)
    # DBD.waitTargetPositionReached(8)

    # Close Communication
    time.sleep(5)
    DBD.stop()


if __name__ == '__main__':
    mainBee()
